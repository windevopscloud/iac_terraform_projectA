"""PostgreSQL access. One short connection per request, so a rotated
password (mounted as a file) is picked up without restarting the pod."""
import logging
import os
import time

import psycopg
from psycopg.errors import UniqueViolation  # noqa: F401  (re-exported)
from psycopg.rows import dict_row

log = logging.getLogger(__name__)


def _password():
    path = os.environ.get("DB_PASSWORD_FILE")
    if path:
        with open(path, encoding="utf-8") as fh:
            return fh.read().strip()
    return os.environ["DB_PASSWORD"]


def connect():
    return psycopg.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", "5432")),
        dbname=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=_password(),
        sslmode=os.environ.get("DB_SSLMODE", "prefer"),
        connect_timeout=5,
        row_factory=dict_row,
    )


SCHEMA = [
    """CREATE TABLE IF NOT EXISTS users (
        id            TEXT PRIMARY KEY,
        name          TEXT NOT NULL,
        email         TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        pw_version    INTEGER NOT NULL DEFAULT 1,
        failed_logins INTEGER NOT NULL DEFAULT 0,
        locked_until  TIMESTAMPTZ,
        created_at    TIMESTAMPTZ NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS challenges (
        id         TEXT PRIMARY KEY,
        purpose    TEXT NOT NULL,
        email      TEXT NOT NULL,
        name       TEXT,
        user_id    TEXT,
        new_email  TEXT,
        code_hash  TEXT NOT NULL,
        code2_hash TEXT,
        attempts   INTEGER NOT NULL DEFAULT 0,
        verified   BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMPTZ NOT NULL,
        expires_at TIMESTAMPTZ NOT NULL
    )""",
    "CREATE INDEX IF NOT EXISTS challenges_email_purpose ON challenges (email, purpose)",
]


def init_schema(retries=30, delay=2):
    """Create the tables. Retries because the database may still be starting,
    and because two pods can start at the same moment."""
    for attempt in range(1, retries + 1):
        try:
            with connect() as conn:
                for statement in SCHEMA:
                    conn.execute(statement)
            log.info("database schema ready")
            return
        except Exception as exc:  # noqa: BLE001
            log.warning("schema setup attempt %s/%s failed: %s", attempt, retries, exc)
            time.sleep(delay)
    raise SystemExit("database not reachable, giving up")
