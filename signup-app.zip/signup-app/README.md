# Signup demo (Flask + PostgreSQL)

Flow: register (name + e-mail) → 4-digit code by mail → set password → login →
"Thank you for Joining {Name}, {Mail ID}" → reset password → change e-mail
(one 4-digit code to the old address, another to the new one) → login shows the new e-mail.

## Run locally
    docker compose up --build
    open http://localhost:8000      # app
    open http://localhost:8025      # Mailpit inbox: the 4-digit codes arrive here

## Build and push to ECR
    aws ecr create-repository --repository-name signup-app
    aws ecr get-login-password | docker login --username AWS --password-stdin <ACCOUNT>.dkr.ecr.<REGION>.amazonaws.com
    docker build -t signup-app:1.0.0 .
    docker tag signup-app:1.0.0 <ACCOUNT>.dkr.ecr.<REGION>.amazonaws.com/signup-app:1.0.0
    docker push <ACCOUNT>.dkr.ecr.<REGION>.amazonaws.com/signup-app:1.0.0

## Deploy on EKS
1. Create RDS PostgreSQL (isolated subnets), allow 5432 only from the node SG.
2. Create secret `signup-secrets` (SECRET_KEY, DB_PASSWORD, SMTP_USER, SMTP_PASSWORD).
   SMTP: Amazon SES SMTP credentials (verify sender/domain; leave SES sandbox for real recipients).
3. Edit placeholders in `k8s/app.yaml`, then `kubectl apply -f k8s/app.yaml`.

Password rotation: the DB password is read per connection from `DB_PASSWORD`
(or a file at `DB_PASSWORD_FILE`). With an env var, restart pods after rotation
(Reloader does this); with a mounted secret file, no restart is needed.

## Tests
    python -m unittest tests.test_flow     # uses a SQLite shim, no Postgres needed
